var a=[1,2,3];
function aritmetica( param){
	var s=0;
	for ( i=0;i<param.length;i++)
		s=s+param[i];
	return s/param.length;
}
var s="(";
for ( i=0;i<a.length;i++){
	if(i==a.length - 1)
		s+=a[i];
	else
		s+= a[i] + "+";
}
s+=")/"+ a.length+"=";
s+=aritmetica(a); 
console.log(s);
